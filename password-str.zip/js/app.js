const password_input     = document.getElementById('password_field');
const password_strength  = document.getElementById('password_strength');
const strength_indicator = document.getElementById('password_strength_indicator')

let percentage = 0;

function password_meter() {
    percentage = password_input.value.length * 6.25;

    if(percentage >= 100) {
        percentage = 100;
    }

    password_strength.style.width = percentage + "%";

    if(password_input.value.length == 0) {
        strength_indicator.style.display = 'none';
    } else {
        strength_indicator.style.display = 'block';
    }

    if(percentage < 50) {
        password_strength.classList.add('red');
        password_strength.classList.remove('yellow');

        strength_indicator.innerHTML = 'Weak';
    } else if(percentage >= 50 && percentage < 80) {
        password_strength.classList.remove('red');
        password_strength.classList.add('yellow');
        
        strength_indicator.innerHTML = 'Average';
    } else {
        password_strength.classList.remove('red');
        password_strength.classList.remove('yellow');

        strength_indicator.innerHTML = 'Strong';
    }
}

password_input.oninput = password_meter;